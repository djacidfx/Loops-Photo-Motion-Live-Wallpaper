package com.demo.livwllpaper.Interfaces;


public interface onposclickedadapter {
    void on_position_clicked(int i);
}
