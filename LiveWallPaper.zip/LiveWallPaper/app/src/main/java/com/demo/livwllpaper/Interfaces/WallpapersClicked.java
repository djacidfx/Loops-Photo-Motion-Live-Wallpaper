package com.demo.livwllpaper.Interfaces;


public interface WallpapersClicked {
    void on_clicked_position(int i, String str);
}
