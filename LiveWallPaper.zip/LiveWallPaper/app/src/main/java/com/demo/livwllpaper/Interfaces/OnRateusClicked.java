package com.demo.livwllpaper.Interfaces;


public interface OnRateusClicked {
    void on_rate_clicked();
}
