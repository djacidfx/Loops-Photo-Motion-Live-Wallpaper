package com.demo.livwllpaper.Interfaces;


public interface Onvideodownloaded {
    void on_downloaded(String str);
}
